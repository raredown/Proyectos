<?php
/**
 * ShoeFixture
 *
 */
class ShoeFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'primary'),
		'idProduct' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'index'),
		'precio' => array('type' => 'float', 'null' => false, 'default' => null),
		'name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 25, 'collate' => 'utf8_unicode_ci', 'charset' => 'utf8'),
		'created' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'modified' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1),
			'id' => array('column' => array('id', 'idProduct', 'precio', 'name', 'created', 'modified'), 'unique' => 0),
			'idProduct' => array('column' => 'idProduct', 'unique' => 0)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_unicode_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'idProduct' => 1,
			'precio' => 1,
			'name' => 'Lorem ipsum dolor sit a',
			'created' => '2014-06-06 09:06:03',
			'modified' => '2014-06-06 09:06:03'
		),
	);

}
