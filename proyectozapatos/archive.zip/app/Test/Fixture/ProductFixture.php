<?php
/**
 * ProductFixture
 *
 */
class ProductFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'primary'),
		'idProveedor' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'index'),
		'idShoe' => array('type' => 'integer', 'null' => false, 'default' => null, 'key' => 'index'),
		'name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 25, 'collate' => 'utf8_unicode_ci', 'charset' => 'utf8'),
		'created' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'modified' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1),
			'id' => array('column' => array('id', 'idProveedor', 'idShoe', 'name', 'created', 'modified'), 'unique' => 0),
			'idProveedor' => array('column' => 'idProveedor', 'unique' => 0),
			'idShoe' => array('column' => 'idShoe', 'unique' => 0)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_unicode_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'idProveedor' => 1,
			'idShoe' => 1,
			'name' => 'Lorem ipsum dolor sit a',
			'created' => '2014-06-06 09:05:49',
			'modified' => '2014-06-06 09:05:49'
		),
	);

}
